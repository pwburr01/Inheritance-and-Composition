﻿//C7353
//due: 9/11/2017
//CIS 200-01
//Program 0
//class designed to implement everything built so far in the program and to display it

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    class Program
    {
        public static void Main(string[] args)
        {
            //lists created for addresses
            List<Address> addresses = new List<Address>();

            addresses.Add(new Address("Phillip Burress", "222 City Street", "Louisville", "KY", 40217));
            addresses.Add(new Address("Andrew Wright", "323 Drs Drive", "Indianapolis", "IN", 55254));
            addresses.Add(new Address("Harry Potter", "Hogwarts","Gryffindor Common Room" , "Nashville", "TN", 65856));

            //lists created for letters
            List<Parcel> parcels = new List<Parcel>();

            parcels.Add(new Letter(addresses[0], addresses[2], .25m));
            parcels.Add(new Letter(addresses[1], addresses[0], .75m));
            parcels.Add(new Letter(addresses[2], addresses[1], .9m));



            //writeline that will display the items
            Console.WriteLine("List of transactions:\n");
            foreach (Letter par in parcels)
            {
                Console.WriteLine("{0}", par);
                Pause();
            }



        }

        //precondition:none
        //postcondition:Will create a stoppage point so you can easily view all the items in each iteration of the loop 
            public static void Pause()
            {
                Console.WriteLine();
                Console.WriteLine("Press Enter to Continue.");
                Console.ReadLine();

                Console.Clear();
            }

        
    }
}
