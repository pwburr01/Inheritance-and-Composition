﻿//C7353
//due: 9/11/2017
//CIS 200-01
//Program 0
//this is the abstract base class for the shipment system


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Prog0
{
    public abstract class Parcel
    {
        //establishes private backing fields
        private Address _originAddress;
        private Address _returnAddress;
        //constructor for the class
        public Parcel(Address origAddress, Address returnAddress)
        {
            OriginAddress = origAddress;
            ReturnAddress = returnAddress;
        }
        //precondition: none
        //postcondition: ensures the proper output 
        public Address OriginAddress
        {
            get
            {
                return _originAddress;
            }

            set
            {
                if (!string.IsNullOrEmpty(value.ToString()))
                {
                    _originAddress = value;
                }
                else
                {
                    throw new ArgumentOutOfRangeException($"{nameof(OriginAddress)}", value,
                          $"{nameof(OriginAddress)} must be a valid U.S. Zip-Code.");
                }
            }
            
        }
        //precondition: none
        //postcondition: ensures the proper output 
        public Address ReturnAddress
        {
            get
            {
                return _returnAddress;
            }

            set
            {
                if (!string.IsNullOrEmpty(value.ToString()))
                {
                    _returnAddress = value;
                }
                else
                {
                    throw new ArgumentOutOfRangeException($"{nameof(ReturnAddress)}", value,
                       $"{nameof(ReturnAddress)} must be a valid U.S. Zip-Code.");
                }
            }

        }

        //precondition: none
        //postcondition: ensures the proper output for fees
        public abstract decimal CalcCost(decimal shipCost);

        //precondition: none
        //postcondition: will return the proper form of the text
        public override string ToString()
        {
            string NL = Environment.NewLine;
           
                return $"Origin Address: {NL} {OriginAddress} {NL} Return Address: {ReturnAddress} {NL}";
            
        }


    }

}