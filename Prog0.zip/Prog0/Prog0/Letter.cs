﻿//C7353
//due: 9/11/2017
//CIS 200-01
//Program 0
//this class is a derived class from the Parcel base class

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    class Letter : Parcel
    {
        //confirms the private backing fields
        private decimal _fixedCost;
        //constructor for the class
        public Letter(Address origAddress, Address returnAddress, decimal fixedCost) : base(origAddress,returnAddress)
        {
            _fixedCost = fixedCost;
        }

        //precondition: none
        //postcondition: ensures the proper output for shipping cost
        public override decimal CalcCost(decimal shipCost)
        {
            return _fixedCost;
        }

        //precondition: none
        //postcondition: will return the proper form of the text
        public override string ToString()
        {
            string NL = Environment.NewLine;


            return $"Origin Address: {NL} {OriginAddress} {NL} Return Address: {ReturnAddress} {NL} Shipping Cost: {CalcCost(_fixedCost).ToString("C")} {NL}";

        }

    }
}
