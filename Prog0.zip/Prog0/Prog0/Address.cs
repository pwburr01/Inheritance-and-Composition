﻿//C7353
//due: 9/11/2017
//CIS 200-01
//Program 0
//this class is used in the parcel class to build addresses

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace Prog0
{
    public class Address
    {
        //establishes private backing fields
        private string _name;
        private string _addressLine1;
        private string _addressLine2;
        private string _city;
        private string _state;
        private int _zip;
        //constructor for the class
        public Address(string name, string addressLine1, string addressLine2, string city, string state, int zip)
        {
            Name = name;
            Address1 = addressLine1;
            Address2 = addressLine2;
            City = city;
            State = state;
            Zip = zip;
        }
        //overridden constructor for the class
        public Address(string name, string addressLine1, string city, string state, int zip)
        {
            Name = name;
            Address1 = addressLine1;
            Address2 = " ";
            City = city;
            State = state;
            Zip = zip;
        }
        //precondition: none
        //postcondition: ensures the proper output 
        public string Name
        {
            get
            {
                return _name;
            }

            set
            {
                if (!string.IsNullOrWhiteSpace(value)) // IsNullOrWhiteSpace includes tests for null, empty, or all whitespace
                    _name = value.Trim();
                else
                    throw new ArgumentOutOfRangeException($"{nameof(Name)}", value,
                        $"{nameof(Name)} must not be null or empty");
            }
        }
        //precondition: none
        //postcondition: ensures the proper output 
        public string Address1
        {
            get
            {
                return _addressLine1;
            }

            set
            {
                if (!string.IsNullOrWhiteSpace(value)) // IsNullOrWhiteSpace includes tests for null, empty, or all whitespace
                    _addressLine1 = value.Trim();
                else
                    throw new ArgumentOutOfRangeException($"{nameof(Address1)}", value,
                        $"{nameof(Address1)} must not be null or empty");
            }
        }
        //precondition: none
        //postcondition: ensures the proper output 
        public string Address2
        {
            get
            {
                return _addressLine2;
            }

            set
            {
                if (!string.IsNullOrEmpty(value)) // IsNullOrWhiteSpace includes tests for null, empty, or all whitespace
                    _addressLine2 = value.Trim();
                else
                    throw new ArgumentOutOfRangeException($"{nameof(Address2)}", value,
                        $"{nameof(Address2)} must not be null or empty");
            }
        }
        //precondition: none
        //postcondition: ensures the proper output 
        public string City
        {
            get
            {
                return _city;
            }

            set
            {
                if (!string.IsNullOrWhiteSpace(value)) // IsNullOrWhiteSpace includes tests for null, empty, or all whitespace
                    _city = value.Trim();
                else
                    throw new ArgumentOutOfRangeException($"{nameof(City)}", value,
                        $"{nameof(City)} must not be null or empty");
            }
        }
        //precondition: none
        //postcondition: ensures the proper output 
        public string State
        {
            get
            {
                return _state;
            }

            set
            {
                if (!string.IsNullOrWhiteSpace(value)) // IsNullOrWhiteSpace includes tests for null, empty, or all whitespace
                    _state = value.Trim();
                else
                    throw new ArgumentOutOfRangeException($"{nameof(State)}", value,
                        $"{nameof(State)} must not be null or empty");
            }
        }

        //NO MAGIC NUMBERS
        int minZip = 0;
        int maxZip = 99999;


        //precondition: none
        //postcondition: ensures the proper output 
        public int Zip
        {
            get
            {
                return _zip;
            }
            set
            {
                if (value < minZip || value > maxZip)
                {
                    throw new ArgumentOutOfRangeException($"{nameof(Zip)}", value,
                        $"{nameof(Zip)} must be a valid U.S. Zip-Code.");
                }

                else
                {
                    _zip = value;
                }
            }
        }
        //precondition: none
        //postcondition: will return the proper form of the text
        public override string ToString()
        {
            string NL = Environment.NewLine;

            if (string.IsNullOrWhiteSpace(Address2))
            {
                return $"{Name} {NL} {Address1} {NL} {City}, {State} {Zip.ToString("D5")} {NL}";
            }
            else
            {
                return $"{Name} {NL} {Address1} {NL} {Address2} {NL} {City}, {State} {Zip.ToString("D5")} {NL}";
            }
        }

    }
}


